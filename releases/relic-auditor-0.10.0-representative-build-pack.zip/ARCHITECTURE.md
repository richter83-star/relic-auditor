# Proposed architecture

- **Components:** ['cap_evaluate', 'cap_report']
- **New Components:** ['Bounded input validation', 'End-to-end verification']
- **Boundary:** New product workspace only; original scan target remains read-only.
