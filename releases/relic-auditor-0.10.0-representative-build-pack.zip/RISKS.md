# Risks

- Demand remains unvalidated
- A Build Pack is decision support, not proof the product will work or sell.
- Market, pricing, and GTM claims remain hypotheses until validated.
