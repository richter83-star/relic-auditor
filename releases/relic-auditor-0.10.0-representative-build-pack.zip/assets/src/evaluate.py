def evaluate(value):
    return {'score': bool(value)}
