def report(result):
    return {'result': result}
