# MVP scope

- **Mvp In:** []
- **Mvp Out:** []
- **Manual Work Allowed:** Review remains manual.
