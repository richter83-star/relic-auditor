# Acceptance criteria

- Every implementation claim resolves to bundled evidence or is labeled new work.
- Approved asset hashes and manifest checksums verify.
- No target code is executed and the scanned source remains unchanged.
- Generated criteria remain unverified until a later approved build session.
