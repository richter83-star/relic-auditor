# Product brief

- **Product Concept:** A bounded evaluation workflow with a traceable result.
- **Target User:** Operations teams
- **Problem Solved:** Evaluate supplied records and return a reviewable report.
- **Recommended Next Step:** Validate the narrow workflow with a buyer.
