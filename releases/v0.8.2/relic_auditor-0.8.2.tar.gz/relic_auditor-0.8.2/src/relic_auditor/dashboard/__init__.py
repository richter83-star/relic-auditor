"""Local interactive dashboard support for Relic Auditor.

The core module deliberately has no Qt import so dashboard scans and exports
remain testable when the optional GUI dependency is not installed.
"""

from .core import (
    DashboardBundle,
    DashboardOptions,
    build_cleanup_plan,
    candidate_key,
    export_dashboard_bundle,
    run_dashboard_audit,
    validate_report_output,
)

__all__ = [
    "DashboardBundle",
    "DashboardOptions",
    "build_cleanup_plan",
    "candidate_key",
    "export_dashboard_bundle",
    "run_dashboard_audit",
    "validate_report_output",
]
