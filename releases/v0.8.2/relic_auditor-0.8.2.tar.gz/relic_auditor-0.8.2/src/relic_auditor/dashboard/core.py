from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping

from ..audit import audit_estate
from ..capability_acquisition import (
    AcquisitionResult,
    analyze_capability_acquisition,
    write_acquisition_reports,
)
from ..models import AuditResult, Candidate, ScanLimits
from ..llm import (
    LLMReasoningConfig,
    LLMReasoningResult,
    reason_about_acquisition,
    write_llm_reports,
)
from ..llm import claude_code
from ..llm.config import ProfileStore
from ..llm.schemas import LLMProfile
from ..product_discovery import DiscoveryConfig, DiscoveryResult, discover_products
from ..product_discovery.reports import write_product_reports
from ..reports import write_reports
from ..safety import redact_structure
from ..technical_truth import (
    TechnicalTruthConfig,
    TechnicalTruthResult,
    analyze_technical_truth,
)
from ..technical_truth.reports import write_technical_truth_reports


ProgressCallback = Callable[[int, str], None]
VALID_DECISIONS = frozenset({"keep", "extract", "archive", "review"})

#: Reasoning provider kinds surfaced by the dashboard. Claude Max runs through
#: the local Claude Code CLI on subscription billing and is not a direct
#: Anthropic API connection; the other kinds use configured profiles.
PROVIDER_KIND_LABELS = {
    "claude-max": "Claude Code / Claude Max (subscription via local Claude Code CLI)",
    "api-key": "Anthropic or OpenAI-compatible API key (metered API billing)",
    "oauth": "Generic OAuth provider (standards-based profile)",
}
DEFAULT_CLAUDE_MAX_PROFILE = "Claude-Max"


def ensure_claude_max_profile(
    name: str = DEFAULT_CLAUDE_MAX_PROFILE,
    *,
    model: str = "sonnet",
    effort: str = claude_code.DEFAULT_EFFORT,
    store: ProfileStore | None = None,
) -> LLMProfile:
    """Create or update the dashboard's Claude Code subscription profile."""

    if model not in claude_code.MODEL_ALIASES:
        raise ValueError(
            "Claude Code model alias must be one of: "
            + ", ".join(claude_code.MODEL_ALIASES)
        )
    profile = LLMProfile(
        name=name,
        protocol="claude-code",
        model=model,
        base_url="",
        auth_mode="claude-subscription",
        effort=effort,
    )
    profile.validate()
    (store or ProfileStore()).save(profile)
    return profile


def claude_max_status(
    name: str = DEFAULT_CLAUDE_MAX_PROFILE,
    *,
    store: ProfileStore | None = None,
    runner: claude_code.SubprocessRunner | None = None,
) -> dict[str, object]:
    """Safe readiness report for the dashboard; never includes account

    emails, organization identifiers, tokens, or credential paths."""

    try:
        profile = (store or ProfileStore()).get(name)
    except KeyError:
        profile = LLMProfile(
            name=name,
            protocol="claude-code",
            model="sonnet",
            base_url="",
            auth_mode="claude-subscription",
            effort=claude_code.DEFAULT_EFFORT,
        )
    return claude_code.safe_status(profile, runner=runner)


def launch_claude_login() -> int:
    """Open the official ``claude auth login`` flow. Relic never intercepts

    or parses the resulting OAuth token."""

    return claude_code.login()


@dataclass(frozen=True)
class DashboardOptions:
    """Bounded local scan controls exposed by the desktop interface."""

    include_hidden: bool = False
    max_file_mb: int = 10
    max_zip_members: int = 20_000
    technical_truth: bool = True
    product_discovery: bool = False
    capability_acquisition: bool = False
    max_opportunities: int = 6
    technical_max_file_mb: int = 2
    max_graph_nodes: int = 100_000
    workflow_depth: int = 12
    max_data_flow_edges: int = 50_000
    llm_profile: str | None = None

    def validate(self) -> None:
        values = {
            "max_file_mb": self.max_file_mb,
            "max_zip_members": self.max_zip_members,
            "max_opportunities": self.max_opportunities,
            "technical_max_file_mb": self.technical_max_file_mb,
            "max_graph_nodes": self.max_graph_nodes,
            "workflow_depth": self.workflow_depth,
            "max_data_flow_edges": self.max_data_flow_edges,
        }
        invalid = [name for name, value in values.items() if value <= 0]
        if invalid:
            raise ValueError(f"scan limits must be positive: {', '.join(invalid)}")
        if self.llm_profile is not None and not self.llm_profile.strip():
            raise ValueError("LLM profile cannot be blank")


@dataclass
class DashboardBundle:
    """All in-memory results produced by one dashboard scan."""

    audit: AuditResult
    options: DashboardOptions
    technical_truth: TechnicalTruthResult | None = None
    discovery: DiscoveryResult | None = None
    acquisition: AcquisitionResult | None = None
    llm_reasoning: LLMReasoningResult | None = None


def run_dashboard_audit(
    target: Path,
    options: DashboardOptions | None = None,
    progress: ProgressCallback | None = None,
) -> DashboardBundle:
    """Run the existing engines without writing reports or a persistent cache."""

    active = options or DashboardOptions()
    active.validate()
    resolved_target = target.expanduser().resolve()
    _progress(progress, 5, "Validating the selected estate")
    if not resolved_target.exists():
        raise FileNotFoundError(f"target does not exist: {resolved_target}")
    if not resolved_target.is_dir():
        raise NotADirectoryError(f"target is not a folder: {resolved_target}")

    _progress(progress, 15, "Inventorying files and inspecting ZIPs virtually")
    audit = audit_estate(
        resolved_target,
        limits=ScanLimits(
            max_file_bytes=active.max_file_mb * 1024 * 1024,
            max_zip_members=active.max_zip_members,
        ),
        include_hidden=active.include_hidden,
    )

    truth = None
    run_truth = active.technical_truth or active.product_discovery
    if run_truth:
        _progress(progress, 48, "Reconstructing technical truth and reachability")
        truth = analyze_technical_truth(
            audit,
            TechnicalTruthConfig(
                max_file_size=active.technical_max_file_mb * 1024 * 1024,
                max_graph_nodes=active.max_graph_nodes,
                workflow_depth=active.workflow_depth,
                use_persistent_cache=False,
                resolve_git_lineage=True,
                max_data_flow_edges=active.max_data_flow_edges,
            ),
        )

    acquisition = None
    if active.capability_acquisition or active.llm_profile:
        _progress(progress, 70, "Matching bounded-autonomy capability evidence")
        acquisition = analyze_capability_acquisition(audit)

    discovery = None
    if active.product_discovery:
        _progress(progress, 78, "Ranking evidence-backed product opportunities")
        discovery = discover_products(
            audit,
            DiscoveryConfig(
                max_opportunities=active.max_opportunities,
                offline=True,
                market_validation=False,
                reasoning_provider="none",
            ),
            technical_truth=truth,
        )

    llm_reasoning = None
    if active.llm_profile and acquisition is not None:
        _progress(progress, 90, "Requesting optional redacted LLM interpretation")
        llm_reasoning = reason_about_acquisition(
            acquisition,
            LLMReasoningConfig(profile=active.llm_profile),
        )

    _progress(progress, 100, "Audit complete — no scanned file was changed")
    return DashboardBundle(
        audit=audit,
        options=active,
        technical_truth=truth,
        discovery=discovery,
        acquisition=acquisition,
        llm_reasoning=llm_reasoning,
    )


def validate_report_output(target: Path, output: Path) -> Path:
    """Require every dashboard export to remain outside the scanned estate."""

    resolved_target = target.expanduser().resolve()
    resolved_output = output.expanduser().resolve()
    if resolved_output == resolved_target or resolved_output.is_relative_to(resolved_target):
        raise ValueError(
            "report output must be outside the scanned target so the estate remains read-only"
        )
    return resolved_output


def export_dashboard_bundle(
    bundle: DashboardBundle,
    output: Path,
    decisions: Mapping[str, str] | None = None,
) -> list[Path]:
    """Export the canonical reports plus the dashboard's advisory cleanup plan."""

    destination = validate_report_output(bundle.audit.target, output)
    normalized = _normalize_decisions(decisions or {})
    written = write_reports(bundle.audit, destination)
    if bundle.technical_truth is not None:
        written.extend(write_technical_truth_reports(bundle.technical_truth, destination))
    if bundle.discovery is not None:
        written.extend(write_product_reports(bundle.discovery, destination))
    if bundle.acquisition is not None:
        written.extend(write_acquisition_reports(bundle.acquisition, destination))
    if bundle.llm_reasoning is not None:
        written.extend(write_llm_reports(bundle.llm_reasoning, destination))

    plan_path = destination / "cleanup-plan.json"
    plan_path.write_text(
        json.dumps(
            redact_structure(build_cleanup_plan(bundle, normalized)),
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    written.append(plan_path)
    return written


def candidate_key(kind: str, path: str) -> str:
    return f"{kind}:{path}"


def build_cleanup_plan(
    bundle: DashboardBundle,
    decisions: Mapping[str, str] | None = None,
) -> dict[str, object]:
    """Create deterministic, advisory-only decision metadata."""

    normalized = _normalize_decisions(decisions or {})
    known = _candidate_index(bundle.audit)
    items = []
    for key, decision in sorted(normalized.items()):
        candidate = known.get(key)
        items.append(
            {
                "candidate_key": key,
                "decision": decision,
                "path": candidate.path if candidate else key.partition(":")[2],
                "source_recommendation": candidate.kind if candidate else "custom",
                "reason": candidate.reason if candidate else "User-authored dashboard decision.",
                "confidence": candidate.confidence if candidate else "user",
                "project_root": candidate.project_root if candidate else None,
            }
        )
    return {
        "schema_version": "1.0",
        "advisory_only": True,
        "target_name": bundle.audit.target.name,
        "safety": {
            "files_modified": False,
            "files_moved": False,
            "files_deleted": False,
            "source_executed": False,
        },
        "decision_counts": {
            decision: sum(item["decision"] == decision for item in items)
            for decision in sorted(VALID_DECISIONS)
        },
        "decisions": items,
    }


def _candidate_index(audit: AuditResult) -> dict[str, Candidate]:
    groups = (
        ("extract", audit.extract_candidates),
        ("archive", audit.archive_candidates),
        ("delete-review", audit.delete_candidates),
    )
    return {
        candidate_key(kind, candidate.path): candidate
        for kind, candidates in groups
        for candidate in candidates
    }


def _normalize_decisions(decisions: Mapping[str, str]) -> dict[str, str]:
    normalized = {}
    for key, value in decisions.items():
        decision = value.strip().lower()
        if decision not in VALID_DECISIONS:
            raise ValueError(
                f"unsupported decision {value!r}; expected one of "
                f"{', '.join(sorted(VALID_DECISIONS))}"
            )
        normalized[str(key)] = decision
    return normalized


def _progress(callback: ProgressCallback | None, value: int, message: str) -> None:
    if callback is not None:
        callback(value, message)
